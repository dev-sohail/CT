-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: nexus
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('5c785c036466adea360111aa28563bfd556b5fba','i:2;',1786855228),('5c785c036466adea360111aa28563bfd556b5fba:timer','i:1786855228;',1786855228),('7c2150d7106073168321f39ec452420d','i:1;',1786855210),('7c2150d7106073168321f39ec452420d:timer','i:1786855210;',1786855210),('830b3b63aeb7c393f1a75d0894c14921','i:1;',1786855233),('830b3b63aeb7c393f1a75d0894c14921:timer','i:1786855233;',1786855233),('a3affa0d1e1a3c72b78aa984c3367a05','i:1;',1786850891),('a3affa0d1e1a3c72b78aa984c3367a05:timer','i:1786850891;',1786850891),('a75f3f172bfb296f2e10cbfc6dfc1883','i:2;',1786855228),('a75f3f172bfb296f2e10cbfc6dfc1883:timer','i:1786855228;',1786855228),('b37e2b0b86a8368405df02e0b66d0b39','i:1;',1786855167),('b37e2b0b86a8368405df02e0b66d0b39:timer','i:1786855167;',1786855167),('d2bfa8e8b749d2772a21edee7b70a2b3','i:2;',1786608038),('d2bfa8e8b749d2772a21edee7b70a2b3:timer','i:1786608038;',1786608038),('df21bfa12c4e294c70f64916c0fbc9a5','i:1;',1786854357),('df21bfa12c4e294c70f64916c0fbc9a5:timer','i:1786854357;',1786854357),('e7cf66797159dc3cd3e85f72e15bb551','i:1;',1786854552),('e7cf66797159dc3cd3e85f72e15bb551:timer','i:1786854552;',1786854552),('f1f70ec40aaa556905d4a030501c0ba4','i:32;',1786855230),('f1f70ec40aaa556905d4a030501c0ba4:timer','i:1786855230;',1786855230);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_devices`
--

DROP TABLE IF EXISTS `identity_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `last_seen_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `identity_devices_user_id_foreign` (`user_id`),
  KEY `identity_devices_device_id_index` (`device_id`),
  CONSTRAINT `identity_devices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `identity_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_devices`
--

LOCK TABLES `identity_devices` WRITE;
/*!40000 ALTER TABLE `identity_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `identity_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_model_has_roles`
--

DROP TABLE IF EXISTS `identity_model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_model_has_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_has_roles_unique` (`role_id`,`model_id`,`model_type`),
  KEY `identity_model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `identity_model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `identity_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_model_has_roles`
--

LOCK TABLES `identity_model_has_roles` WRITE;
/*!40000 ALTER TABLE `identity_model_has_roles` DISABLE KEYS */;
INSERT INTO `identity_model_has_roles` VALUES (1,1,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(2,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',2,'2026-08-13 02:13:30','2026-08-13 02:13:30'),(3,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'2026-08-13 02:52:47','2026-08-13 02:52:47'),(4,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',4,'2026-08-15 22:27:11','2026-08-15 22:27:11'),(5,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',5,'2026-08-15 23:24:57','2026-08-15 23:24:57'),(6,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',6,'2026-08-15 23:28:12','2026-08-15 23:28:12'),(7,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',7,'2026-08-15 23:38:26','2026-08-15 23:38:26'),(8,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',8,'2026-08-15 23:39:10','2026-08-15 23:39:10'),(9,3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',9,'2026-08-15 23:39:33','2026-08-15 23:39:33');
/*!40000 ALTER TABLE `identity_model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_password_reset_tokens`
--

DROP TABLE IF EXISTS `identity_password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_password_reset_tokens`
--

LOCK TABLES `identity_password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `identity_password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `identity_password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_permissions`
--

DROP TABLE IF EXISTS `identity_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_permissions_name_unique` (`name`),
  UNIQUE KEY `identity_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_permissions`
--

LOCK TABLES `identity_permissions` WRITE;
/*!40000 ALTER TABLE `identity_permissions` DISABLE KEYS */;
INSERT INTO `identity_permissions` VALUES (1,'Users view','users.view','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(2,'Users create','users.create','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(3,'Users update','users.update','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(4,'Users delete','users.delete','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(5,'Users assign_role','users.assign_role','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(6,'Dashboard view','dashboard.view','identity','2026-08-13 01:56:04','2026-08-13 01:56:04'),(7,'Admin access','admin.access','identity','2026-08-13 01:56:04','2026-08-13 01:56:04');
/*!40000 ALTER TABLE `identity_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_personal_access_tokens`
--

DROP TABLE IF EXISTS `identity_personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `tokenable_type` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_personal_access_tokens_token_unique` (`token`),
  KEY `ipt_tokenable_idx` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_personal_access_tokens`
--

LOCK TABLES `identity_personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `identity_personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `identity_personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_role_permission`
--

DROP TABLE IF EXISTS `identity_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_role_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_role_permission_role_id_permission_id_unique` (`role_id`,`permission_id`),
  KEY `identity_role_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `identity_role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `identity_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `identity_role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `identity_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_role_permission`
--

LOCK TABLES `identity_role_permission` WRITE;
/*!40000 ALTER TABLE `identity_role_permission` DISABLE KEYS */;
INSERT INTO `identity_role_permission` VALUES (1,1,7,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(2,1,6,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(3,1,5,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(4,1,2,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(5,1,4,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(6,1,3,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(7,1,1,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(8,2,6,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(9,2,5,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(10,2,2,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(11,2,4,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(12,2,3,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(13,2,1,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(14,3,6,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(15,3,1,'2026-08-13 01:56:39','2026-08-13 01:56:39');
/*!40000 ALTER TABLE `identity_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_roles`
--

DROP TABLE IF EXISTS `identity_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_roles_name_unique` (`name`),
  UNIQUE KEY `identity_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_roles`
--

LOCK TABLES `identity_roles` WRITE;
/*!40000 ALTER TABLE `identity_roles` DISABLE KEYS */;
INSERT INTO `identity_roles` VALUES (1,'Owner','owner','Full access to everything.',1,'2026-08-13 01:56:04','2026-08-13 01:56:04'),(2,'Admin','admin','Administrative access.',1,'2026-08-13 01:56:39','2026-08-13 01:56:39'),(3,'Member','member','Default personal user.',1,'2026-08-13 01:56:39','2026-08-13 01:56:39');
/*!40000 ALTER TABLE `identity_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_sessions`
--

DROP TABLE IF EXISTS `identity_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `identity_sessions_user_id_index` (`user_id`),
  KEY `identity_sessions_last_activity_index` (`last_activity`),
  CONSTRAINT `identity_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `identity_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_sessions`
--

LOCK TABLES `identity_sessions` WRITE;
/*!40000 ALTER TABLE `identity_sessions` DISABLE KEYS */;
INSERT INTO `identity_sessions` VALUES ('4cPzQm8jF2F20oz4vFO6bKhrrFfomUFD2G8uBIE0',NULL,'127.0.0.1','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoidlBsamN3aG9La210SHlXakZuQ3lHT1VFNTFhcFhZZURTYmowcThkRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9hcGkubmV4dXMubG9jYWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1786608608),('6kVwasvvDZio0esF4I9KpU65qjKGsfgDuRkEcc6I',NULL,'127.0.0.1','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoianVvVnpzd3pLbDJQM3poMEROTkFmZ1V4VnhoOGtLTWVUa2VLZ1hBdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTg6Imh0dHA6Ly9uZXh1cy5sb2NhbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1786607557),('ElG3wDKx3s4IQgRywJ8ZE5DQsIRUJM88Mu4zkBNU',NULL,'127.0.0.1','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVlxQ0FlZ2U0cXB4WG1LWDVhdTZBeFlmbXVDRTJ5R2xyTWptT24wMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTg6Imh0dHA6Ly9uZXh1cy5sb2NhbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1786607707),('g1nlChzwIbPQ3sftRzWwub68I9F3uE2Fw3XeJQrx',NULL,'127.0.0.1','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoibUJqclY3bUZEWXU0TVBpSlltMmdGY3R5YktwSUFQWEd5RDFYOHdPSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9hcGkubmV4dXMubG9jYWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1786607973),('mQScfMzFsrpgWGuJxI2GNxkBVb3TRJ0Fd2xFSOPA',NULL,'127.0.0.1','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicHd1ZENFclAxbTVmZzV6eHZMRTlybXBBWll3YXBaN01rbGtwSkJoUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9hcGkubmV4dXMubG9jYWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1786846516),('qCZfKCoBHW9eGPL7QfEN7fHVFHQiHwa3jELB9PuH',NULL,'127.0.0.1','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicU9VSGExTFY3RUw5bUd2QXNDZHFWN2JMSm5UYnl0RlFteFJ4YW9tNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTg6Imh0dHA6Ly9uZXh1cy5sb2NhbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1786607557);
/*!40000 ALTER TABLE `identity_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity_users`
--

DROP TABLE IF EXISTS `identity_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity_users`
--

LOCK TABLES `identity_users` WRITE;
/*!40000 ALTER TABLE `identity_users` DISABLE KEYS */;
INSERT INTO `identity_users` VALUES (1,'Platform Owner','owner@nexus.local',NULL,'$2y$12$4PsELbD8Vhv9Lwdma/D15exAlqrypQ4i.era5GCuSwgkxWx8zcjz.',NULL,1,'2026-08-13 01:56:39','2026-08-15 20:59:13',NULL),(2,'Test','test@nexus.local',NULL,'$2y$12$Ymk1gyQI7V8kQrACRELQj.kkAqFI3djb4Acyjf5KgJimQ.NrJn2G.',NULL,1,'2026-08-13 02:13:30','2026-08-13 02:13:30',NULL),(3,'Test User','test2@nexus.local',NULL,'$2y$12$RFfKcvwgdxSIANZOmyRgf.KZfoJFJGugNlYlGPnGUIy/8tRzFiHK6',NULL,1,'2026-08-13 02:52:47','2026-08-13 02:52:47',NULL),(4,'E2E Other','e2e-other-1786850822623@nexus.local',NULL,'$2y$12$EFFlzTL.7bjpNLbQqB2yAe4nHSwFj.Y6Exg3LBrDvnL4sGjyY0dG.',NULL,1,'2026-08-15 22:27:11','2026-08-15 22:27:11',NULL),(5,'E2E Other','envcheck2@nexus.local',NULL,'$2y$12$Wa6uE0dBN5IrikoUBZEXDOXTXQcOub9a9pNzKd2GrYwKF5Hhr4qxi',NULL,1,'2026-08-15 23:24:57','2026-08-15 23:24:57',NULL),(6,'E2E Other','e2e-other-1786854488760@nexus.local',NULL,'$2y$12$SjxT055t0Clxo5Zh.T3xyuBuWd2hzwbQAcYcWVkqT0Yfrtsl1FMlO',NULL,1,'2026-08-15 23:28:12','2026-08-15 23:28:12',NULL),(7,'E2E Other','e2e-other-1786855102322@nexus.local',NULL,'$2y$12$lLEV7yac2u13ezHxNZ1CPeM2y/fqcr2sMMY9cwW1irnwSSGNKaxTW',NULL,1,'2026-08-15 23:38:26','2026-08-15 23:38:26',NULL),(8,'E2E Other','e2e-other-1786855145704@nexus.local',NULL,'$2y$12$HFHTWBSzprgtFKrJtawmO.yPcQIMRs3D0SNxOfOneYhs6xY59IivW',NULL,1,'2026-08-15 23:39:10','2026-08-15 23:39:10',NULL),(9,'E2E Other','e2e-other-1786855168479@nexus.local',NULL,'$2y$12$egI4Gfsf.g5kZQmDyUHzeO1vxQqzNJkZFod4asw3PE7m.daA4/M1e',NULL,1,'2026-08-15 23:39:33','2026-08-15 23:39:33',NULL);
/*!40000 ALTER TABLE `identity_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2019_12_14_000001_create_personal_access_tokens_table',1),(2,'2026_01_01_000001_create_identity_users_table',1),(3,'2026_01_01_000002_create_identity_rbac_tables',1),(4,'2026_01_01_000003_create_identity_auth_tables',1),(5,'2026_01_01_000004_create_infra_tables',1),(6,'2026_08_16_000001_create_wiki_workspaces_table',2),(7,'2026_08_16_000002_create_wiki_notebooks_table',2),(8,'2026_08_16_000003_create_wiki_sections_table',2),(9,'2026_08_16_000004_create_wiki_projects_table',2),(10,'2026_08_16_000005_create_wiki_pages_table',2),(11,'2026_08_16_000006_create_wiki_blocks_table',2),(12,'2026_08_16_000007_create_wiki_tags_table',2),(13,'2026_08_16_000008_create_wiki_page_versions_table',2),(14,'2026_08_16_000009_create_wiki_templates_table',2),(15,'2026_08_16_000010_create_wiki_questions_table',2),(16,'2026_08_16_000011_create_wiki_references_table',2),(17,'2026_08_16_000012_create_wiki_tasks_table',2),(18,'2026_08_16_000013_create_wiki_reviews_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',2,'curl/8.18.0','518f1969ad5c53cd8134ceb5732bf84799cb165612adc31dbe54860b50e471d9','[\"*\"]',NULL,NULL,'2026-08-13 02:13:30','2026-08-13 02:13:30'),(2,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','4c273afe7601838b495466f2da81c2bd0a47e744aa9a04dbe569333f4fd7f9cc','[\"*\"]',NULL,NULL,'2026-08-13 02:13:43','2026-08-13 02:13:43'),(3,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','9a9910b972dfe87aff9838aaf22be234eff8c85fb646d78f208e459d41017bec','[\"*\"]',NULL,NULL,'2026-08-13 02:52:47','2026-08-13 02:52:47'),(4,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','958ce090c7fec34878b312f543becc6a6b3a1ce9d61871106b81c0956fcd1c39','[\"*\"]',NULL,NULL,'2026-08-13 02:52:47','2026-08-13 02:52:47'),(5,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','48f3c319c186dcf5aac676854303528806c03e3786954512d6cb7c4c8a4f46f3','[\"*\"]',NULL,NULL,'2026-08-13 02:53:05','2026-08-13 02:53:05'),(6,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','9b87a919cbf6b1fa816f5de6f93c2c5608580e086828daeeda5028c1a8a2c54f','[\"*\"]',NULL,NULL,'2026-08-13 02:54:11','2026-08-13 02:54:11'),(7,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','c42e8d9924da2b416136025dca1813b905445088aa25ef494abd292ff6b54f20','[\"*\"]','2026-08-13 02:54:55',NULL,'2026-08-13 02:54:55','2026-08-13 02:54:55'),(8,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',3,'curl/8.18.0','a221c35d414849fc8e60c879c0b8d593097ebfd8c64c762bbc5866fbb9f5fa5c','[\"*\"]','2026-08-13 02:58:29',NULL,'2026-08-13 02:58:29','2026-08-13 02:58:29'),(10,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','ba9e57fda7844042ef181897668ee88f28729190e386c074e5f1fa42950718d8','[\"*\"]',NULL,NULL,'2026-08-15 20:30:44','2026-08-15 20:30:44'),(11,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','68990c118130d2f29ed8e56d0cf927c40a224cc2a176913e7c6172e9f255e339','[\"*\"]','2026-08-15 20:36:17',NULL,'2026-08-15 20:36:16','2026-08-15 20:36:17'),(12,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','4ff7e2700a8d8ce0f37abf3fe08c027a400bf79573f7e1b8120928d5607c6f08','[\"*\"]','2026-08-15 20:36:27',NULL,'2026-08-15 20:36:26','2026-08-15 20:36:27'),(13,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','94b83b4f903c65222d5e495cae2848fefdabb86982f529ddfa3ffeef1fc2d146','[\"*\"]','2026-08-15 20:36:40',NULL,'2026-08-15 20:36:40','2026-08-15 20:36:40'),(14,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','24dac2920b8f171ef5bd01c7a2bfcbcf7270c8e59b84369218509a8466f986fc','[\"*\"]','2026-08-15 20:36:52',NULL,'2026-08-15 20:36:49','2026-08-15 20:36:52'),(15,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','c3b70b13134f633d78e938a029a9739cd5f1d2b6414536a7a69b3925abdacd10','[\"*\"]','2026-08-15 20:37:02',NULL,'2026-08-15 20:37:01','2026-08-15 20:37:02'),(16,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','15320505bd51abe64451e8300106464d85eed5022f87f43de0fbce50c8b92684','[\"*\"]','2026-08-15 20:37:14',NULL,'2026-08-15 20:37:14','2026-08-15 20:37:14'),(17,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','bfed5ce68e079b475e0a5fd142d518d3304a609a2b8a34b1790bfe32a6d35df0','[\"*\"]','2026-08-15 20:37:27',NULL,'2026-08-15 20:37:24','2026-08-15 20:37:27'),(18,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','d05b83478607c99e2ee739ed0b45d699fbe0eefd0856fa4363788fe5dc6871fd','[\"*\"]','2026-08-15 20:37:45',NULL,'2026-08-15 20:37:45','2026-08-15 20:37:45'),(19,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','b2a43ba5d217cde39616be9dea68fe716cd3abe4c8c8c00d64bb2dd3137a3116','[\"*\"]','2026-08-15 20:49:05',NULL,'2026-08-15 20:49:00','2026-08-15 20:49:05'),(20,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','03c3854af0fec1e85fca3cc0c3b3ef7f70262d389b4bfb01ce0589cf52cf95d5','[\"*\"]','2026-08-15 20:49:17',NULL,'2026-08-15 20:49:16','2026-08-15 20:49:17'),(21,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0','22ff27bec20fa9cdc84bb704c5b3ecbe7eaf69608ac24602d37f66425e4c21ff','[\"*\"]','2026-08-15 20:52:58',NULL,'2026-08-15 20:51:07','2026-08-15 20:52:58'),(22,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','a012c81d7e62015503661f25dff7b9744012f9169d7d7e693ed19f99bc2541ac','[\"*\"]',NULL,NULL,'2026-08-15 20:59:14','2026-08-15 20:59:14'),(23,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','c60eaf58654601884512b1c11d33865d096004b7d7c9c5503ce780c9560aaa20','[\"*\"]','2026-08-15 20:59:55',NULL,'2026-08-15 20:59:21','2026-08-15 20:59:55'),(24,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','b54fa2cda272cee3cecd9e7cbd44112576471c605beb6859e8bbfe9021a944da','[\"*\"]',NULL,NULL,'2026-08-15 21:00:26','2026-08-15 21:00:26'),(25,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','25a0afde82515210255fc2ca8ca0bf1500420f2c130c9ad22b0dc8e107186315','[\"*\"]',NULL,NULL,'2026-08-15 21:01:23','2026-08-15 21:01:23'),(26,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','efd48b87a57a396ee1cf6982edca0f59ae752897816176af1545eb0196ab420b','[\"*\"]','2026-08-15 21:03:14',NULL,'2026-08-15 21:02:37','2026-08-15 21:03:14'),(27,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','d68262d425c5092cce716b5cde203b6524b1b83c9369339ea4433c2e73e9574b','[\"*\"]','2026-08-15 21:03:24',NULL,'2026-08-15 21:03:24','2026-08-15 21:03:24'),(28,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','60af8643fa13b722e7a3c2e8e527ec306e1782495cf168867f501d86d0a55404','[\"*\"]','2026-08-15 21:03:29',NULL,'2026-08-15 21:03:29','2026-08-15 21:03:29'),(29,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','8f4c14ebb8ff92c860348084204e8fabd266396ed57e6b72b7653974b3ac7465','[\"*\"]','2026-08-15 21:11:13',NULL,'2026-08-15 21:11:10','2026-08-15 21:11:13'),(30,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','b11caf09b4da1e1f976bf6a95a42bb18957559c9b8eb102a6de88a910d1cf858','[\"*\"]','2026-08-15 22:27:13',NULL,'2026-08-15 22:27:07','2026-08-15 22:27:13'),(31,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',4,'node','9bca1396be0caf331321a99efbcf506755767e0c899e5851c678ab8b8279fa88','[\"*\"]','2026-08-15 22:27:11',NULL,'2026-08-15 22:27:11','2026-08-15 22:27:11'),(32,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','d9f0ca5c5551af492046b8ad523279b85f06fc23419cfc1256d25fa3eb06236c','[\"*\"]','2026-08-15 23:24:58',NULL,'2026-08-15 23:24:57','2026-08-15 23:24:58'),(33,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',5,'curl/8.18.0','fadf21722c9e5d23e34e8541e02f5bd33f25588cf9bb065750849dda8eae85dd','[\"*\"]','2026-08-15 23:24:57',NULL,'2026-08-15 23:24:57','2026-08-15 23:24:57'),(34,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'curl/8.18.0','c9e3dec3fd2f888d5f7d1a5e4b4cebc27e736c286b209b72a5dae38d93eddf27','[\"*\"]','2026-08-15 23:25:04',NULL,'2026-08-15 23:25:03','2026-08-15 23:25:04'),(35,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','557f03666a631a3e24fb6b68a6b54e5efe21b5a49a09ffe3cae0e7ba8a0c4f5d','[\"*\"]','2026-08-15 23:28:14',NULL,'2026-08-15 23:28:09','2026-08-15 23:28:14'),(36,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',6,'node','58c761b28140772963216e3a45d1f180062fbf2d51a902fc7c24d5dd78d5a11d','[\"*\"]','2026-08-15 23:28:12',NULL,'2026-08-15 23:28:12','2026-08-15 23:28:12'),(37,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','59877b4a67ab7cbcc23ca5bf9f41cffab6e70a003d639c15a5eee584cd526aaa','[\"*\"]','2026-08-15 23:38:31',NULL,'2026-08-15 23:38:23','2026-08-15 23:38:31'),(38,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',7,'node','2f15abf96727310793f764c9503d9651a761970db49c3786ca076addd69b1a46','[\"*\"]','2026-08-15 23:38:27',NULL,'2026-08-15 23:38:26','2026-08-15 23:38:27'),(39,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','794e24fadea43a8d499e3436d14ef25d865e1f38035bb579dc2e91e433af25a6','[\"*\"]','2026-08-15 23:39:14',NULL,'2026-08-15 23:39:06','2026-08-15 23:39:14'),(40,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',8,'node','60dec1574642142092153d20a7062b342db22889d6400d628af0ef373b97e9f5','[\"*\"]','2026-08-15 23:39:10',NULL,'2026-08-15 23:39:10','2026-08-15 23:39:10'),(41,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',1,'node','b848623f1760706ccc5eb61749e601731cc23d18fcd606044a8bb5d4a33aa40a','[\"*\"]','2026-08-15 23:39:37',NULL,'2026-08-15 23:39:29','2026-08-15 23:39:37'),(42,'App\\Domains\\CoreIdentityAndAccessKernel\\Models\\User',9,'node','0b7af870c828f0c9caffc9a19e6cf6749597f7c0552b8e973cc4c7fac583cfed','[\"*\"]','2026-08-15 23:39:33',NULL,'2026-08-15 23:39:33','2026-08-15 23:39:33');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_blocks`
--

DROP TABLE IF EXISTS `wiki_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_blocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_blocks_parent_id_foreign` (`parent_id`),
  KEY `wiki_blocks_page_id_sort_order_index` (`page_id`,`sort_order`),
  CONSTRAINT `wiki_blocks_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `wiki_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wiki_blocks_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `wiki_blocks` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_blocks`
--

LOCK TABLES `wiki_blocks` WRITE;
/*!40000 ALTER TABLE `wiki_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_notebooks`
--

DROP TABLE IF EXISTS `wiki_notebooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_notebooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_notebooks_workspace_id_sort_order_index` (`workspace_id`,`sort_order`),
  CONSTRAINT `wiki_notebooks_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_notebooks`
--

LOCK TABLES `wiki_notebooks` WRITE;
/*!40000 ALTER TABLE `wiki_notebooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_notebooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_page_tag`
--

DROP TABLE IF EXISTS `wiki_page_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_page_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` bigint(20) unsigned NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wiki_page_tag_page_id_tag_id_unique` (`page_id`,`tag_id`),
  KEY `wiki_page_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `wiki_page_tag_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `wiki_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wiki_page_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `wiki_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_page_tag`
--

LOCK TABLES `wiki_page_tag` WRITE;
/*!40000 ALTER TABLE `wiki_page_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_page_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_page_versions`
--

DROP TABLE IF EXISTS `wiki_page_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_page_versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `blocks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`blocks`)),
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_page_versions_page_id_id_index` (`page_id`,`id`),
  CONSTRAINT `wiki_page_versions_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `wiki_pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_page_versions`
--

LOCK TABLES `wiki_page_versions` WRITE;
/*!40000 ALTER TABLE `wiki_page_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_page_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_pages`
--

DROP TABLE IF EXISTS `wiki_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'page',
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `difficulty` varchar(255) DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT 0,
  `pinned_at` timestamp NULL DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_pages_project_id_foreign` (`project_id`),
  KEY `wiki_pages_section_id_sort_order_index` (`section_id`,`sort_order`),
  KEY `wiki_pages_is_favorite_index` (`is_favorite`),
  CONSTRAINT `wiki_pages_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `wiki_projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wiki_pages_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `wiki_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_pages`
--

LOCK TABLES `wiki_pages` WRITE;
/*!40000 ALTER TABLE `wiki_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_projects`
--

DROP TABLE IF EXISTS `wiki_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'planned',
  `color` varchar(7) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_projects_workspace_id_foreign` (`workspace_id`),
  CONSTRAINT `wiki_projects_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_projects`
--

LOCK TABLES `wiki_projects` WRITE;
/*!40000 ALTER TABLE `wiki_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_questions`
--

DROP TABLE IF EXISTS `wiki_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_questions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `answer` text DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `difficulty` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_questions_workspace_id_foreign` (`workspace_id`),
  CONSTRAINT `wiki_questions_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_questions`
--

LOCK TABLES `wiki_questions` WRITE;
/*!40000 ALTER TABLE `wiki_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_references`
--

DROP TABLE IF EXISTS `wiki_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_references` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'article',
  `author` varchar(255) DEFAULT NULL,
  `credibility` tinyint(3) unsigned NOT NULL DEFAULT 3,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_references_workspace_id_foreign` (`workspace_id`),
  CONSTRAINT `wiki_references_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_references`
--

LOCK TABLES `wiki_references` WRITE;
/*!40000 ALTER TABLE `wiki_references` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_reviews`
--

DROP TABLE IF EXISTS `wiki_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `page_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'weekly',
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `scheduled_for` date DEFAULT NULL,
  `next_review_at` timestamp NULL DEFAULT NULL,
  `last_reviewed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_reviews_workspace_id_foreign` (`workspace_id`),
  KEY `wiki_reviews_page_id_foreign` (`page_id`),
  CONSTRAINT `wiki_reviews_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `wiki_pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wiki_reviews_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_reviews`
--

LOCK TABLES `wiki_reviews` WRITE;
/*!40000 ALTER TABLE `wiki_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_sections`
--

DROP TABLE IF EXISTS `wiki_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notebook_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_sections_notebook_id_sort_order_index` (`notebook_id`,`sort_order`),
  CONSTRAINT `wiki_sections_notebook_id_foreign` FOREIGN KEY (`notebook_id`) REFERENCES `wiki_notebooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_sections`
--

LOCK TABLES `wiki_sections` WRITE;
/*!40000 ALTER TABLE `wiki_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_tags`
--

DROP TABLE IF EXISTS `wiki_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wiki_tags_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_tags`
--

LOCK TABLES `wiki_tags` WRITE;
/*!40000 ALTER TABLE `wiki_tags` DISABLE KEYS */;
INSERT INTO `wiki_tags` VALUES (1,'e2e',NULL,'2026-08-15 22:27:10','2026-08-15 22:27:10');
/*!40000 ALTER TABLE `wiki_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_tasks`
--

DROP TABLE IF EXISTS `wiki_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `due_date` date DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `taskable_type` varchar(255) DEFAULT NULL,
  `taskable_id` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_tasks_workspace_id_foreign` (`workspace_id`),
  KEY `wiki_tasks_taskable_type_taskable_id_index` (`taskable_type`,`taskable_id`),
  CONSTRAINT `wiki_tasks_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `wiki_workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_tasks`
--

LOCK TABLES `wiki_tasks` WRITE;
/*!40000 ALTER TABLE `wiki_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_templates`
--

DROP TABLE IF EXISTS `wiki_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `blocks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`blocks`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wiki_templates_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_templates`
--

LOCK TABLES `wiki_templates` WRITE;
/*!40000 ALTER TABLE `wiki_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_workspaces`
--

DROP TABLE IF EXISTS `wiki_workspaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_workspaces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_workspaces_user_id_is_default_index` (`user_id`,`is_default`),
  CONSTRAINT `wiki_workspaces_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `identity_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_workspaces`
--

LOCK TABLES `wiki_workspaces` WRITE;
/*!40000 ALTER TABLE `wiki_workspaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_workspaces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-16 10:31:14
